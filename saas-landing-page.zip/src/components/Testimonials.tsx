import React from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';
import { Card } from './ui/Card';

const testimonials = [
  {
    content: "Octopus.ai has completely transformed how we handle customer support. Our response times dropped by 80% within the first week.",
    author: "Sarah Johnson",
    role: "Head of Support at TechFlow",
    avatar: "https://picsum.photos/seed/sarah/100/100",
  },
  {
    content: "The ease of setting up complex workflows is unmatched. What used to take days of engineering time now takes minutes.",
    author: "Michael Chen",
    role: "CTO at StartupX",
    avatar: "https://picsum.photos/seed/michael/100/100",
  },
  {
    content: "I was skeptical about AI agents, but Octopus's reliability won me over. It's like having an extra team working 24/7.",
    author: "Emily Davis",
    role: "Operations Manager at ScaleUp",
    avatar: "https://picsum.photos/seed/emily/100/100",
  },
];

export const Testimonials = () => {
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Trusted by innovators
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Join thousands of companies automating their future.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
            >
              <Card className="p-8 h-full bg-gray-50 border-none">
                <div className="flex gap-1 text-yellow-400 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 text-lg mb-8 italic">"{testimonial.content}"</p>
                <div className="flex items-center gap-4">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.author}
                    className="w-12 h-12 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.author}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
