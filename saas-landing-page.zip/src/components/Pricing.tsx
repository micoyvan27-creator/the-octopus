import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check } from 'lucide-react';
import { Button } from './ui/Button';
import { Card } from './ui/Card';

const plans = [
  {
    name: 'Free',
    price: '$0',
    description: 'Perfect for experimenting and personal projects.',
    features: ['1 AI Agent', '100 executions/month', 'Community Support', 'Basic Templates'],
    cta: 'Get Started',
    popular: false,
  },
  {
    name: 'Starter',
    price: '$0',
    description: 'For small teams and growing startups.',
    features: ['5 AI Agents', '10,000 executions/month', 'Priority Support', 'Advanced Analytics', 'Custom Integrations'],
    cta: 'Start Free Trial',
    popular: true,
  },
  {
    name: 'Pro',
    price: '$0',
    description: 'For scaling businesses with high volume needs.',
    features: ['Unlimited AI Agents', 'Unlimited executions', '24/7 Dedicated Support', 'SSO & Audit Logs', 'SLA Guarantee'],
    cta: 'Contact Sales',
    popular: false,
  },
];

export const Pricing = () => {
  const [isAnnual, setIsAnnual] = useState(true);

  return (
    <section id="pricing" className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
            Simple, transparent pricing
          </h2>
          <p className="text-gray-400 text-lg mb-8">
            The web is completely free. Choose the plan that's right for your business.
          </p>

          <div className="flex items-center justify-center gap-4">
            <span className={`text-sm ${!isAnnual ? 'text-white font-medium' : 'text-gray-400'}`}>Monthly</span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="relative w-14 h-8 bg-indigo-600 rounded-full p-1 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-900"
            >
              <motion.div
                className="w-6 h-6 bg-white rounded-full shadow-sm"
                animate={{ x: isAnnual ? 24 : 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            </button>
            <span className={`text-sm ${isAnnual ? 'text-white font-medium' : 'text-gray-400'}`}>
              Yearly <span className="text-indigo-400 text-xs ml-1">(Save 20%)</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative"
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg z-10">
                  MOST POPULAR
                </div>
              )}
              <Card className={`h-full p-8 flex flex-col ${plan.popular ? 'border-2 border-indigo-500 bg-gray-800' : 'bg-gray-800/50 border-gray-700'}`}>
                <div className="mb-8">
                  <h3 className="text-xl font-semibold text-white mb-2">{plan.name}</h3>
                  <p className="text-gray-400 text-sm mb-6">{plan.description}</p>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-white">{plan.price}</span>
                    <span className="text-gray-400">/mo</span>
                  </div>
                </div>

                <ul className="space-y-4 mb-8 flex-1">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3 text-gray-300 text-sm">
                      <Check className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button
                  variant={plan.popular ? 'primary' : 'outline'}
                  fullWidth
                  className={!plan.popular ? 'border-gray-600 text-white hover:bg-gray-700' : ''}
                >
                  {plan.cta}
                </Button>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
