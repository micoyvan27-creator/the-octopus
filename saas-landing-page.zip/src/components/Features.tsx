import React from 'react';
import { motion } from 'motion/react';
import { Zap, Shield, BarChart3, Users, Layers, Globe } from 'lucide-react';
import { Card } from './ui/Card';

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Our AI engine processes data in milliseconds, ensuring real-time responses for your customers.',
    color: 'text-yellow-500 bg-yellow-50',
  },
  {
    icon: Shield,
    title: 'Enterprise Security',
    description: 'Bank-grade encryption and SOC2 compliance to keep your data safe and secure.',
    color: 'text-blue-500 bg-blue-50',
  },
  {
    icon: BarChart3,
    title: 'Advanced Analytics',
    description: 'Gain deep insights into user behavior and agent performance with our detailed dashboards.',
    color: 'text-green-500 bg-green-50',
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Invite your team, manage roles, and collaborate on agent workflows seamlessly.',
    color: 'text-purple-500 bg-purple-50',
  },
  {
    icon: Layers,
    title: 'Seamless Integration',
    description: 'Connect with your favorite tools like Slack, HubSpot, and Salesforce in one click.',
    color: 'text-pink-500 bg-pink-50',
  },
  {
    icon: Globe,
    title: 'Global Scale',
    description: 'Deploy agents across multiple regions with low latency and high availability.',
    color: 'text-indigo-500 bg-indigo-50',
  },
];

export const Features = () => {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-indigo-600 font-semibold tracking-wide uppercase text-sm"
          >
            Features
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"
          >
            Everything you need to scale
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-lg text-gray-600"
          >
            Powerful tools designed to help you build, manage, and optimize your AI workforce.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-8 h-full hover:shadow-lg transition-shadow duration-300" hoverEffect>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-6 ${feature.color}`}>
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
